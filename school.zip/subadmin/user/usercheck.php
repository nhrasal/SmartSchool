<?php
$user=$_name['name'];
$password=$_name['pass'];
include("../database/config.php");

?>