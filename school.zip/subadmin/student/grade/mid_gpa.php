<?php
$c=$midmark;
if($c<33){
	echo "0.0";
	
	}
else if($c<40){
	
	echo"1.00";
	}
	else if($c<50){
	
	echo"2.00";
	}
	else if($c<60){
	
	echo"3.00";
	}
	else if($c<70){
	
	echo"3.50";
	}
	else if($c<80){
	
	echo"4";
	}
	else if($c>79){
	
	echo"5";
	}
?>