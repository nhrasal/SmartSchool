<?php 


$x=$action;

if($x="active"){
	echo'<p style="color:green">Active</p>';
	
	}
	else
	{
		echo'<p style="color:red">Deactive</p>';
		
		}
	
?>