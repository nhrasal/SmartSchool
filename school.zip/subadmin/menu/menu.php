<a href="index.php"><img src="image/img.jpg" alt="img" style="height:30px; width:30px; border-radius: 14px;"/>DashBoard</a>
   <li class="dropdown">
  
  <a href="../index.php" target="_blank" >View Site</a></li>
  <div>
  
   <li class="dropdown">
    <a href="allteacher.php" class="dropbtn">Teacher</a>
	</li>
    </div>
<div>
   <li class="dropdown">
    <a href="" class="dropbtn">Student ></a>
    <div class="dropdown-content">
    <a href="admission.php">Admission</a>
      <a href="allstudent.php">Student Information</a>
       <a href="attendin.php">Attendance </a>
       <a href="result.php">Result </a>
       <a href="course_info.php">Course </a>
       <a href="class.php">Class </a>
   
    </div>
	</li></div>
    
    
     <li class="dropdown">
    <a href="photoview.php" class="dropbtn">Gallery </a>
</li>
      
      <div>
     <li class="dropdown">
    <a href="vnotice.php" class="dropbtn">Notice </a>
   </li>
      </div>
     <a href="login/logout.php">Logout</a>