<?php

?>

<title>Smart School </title>