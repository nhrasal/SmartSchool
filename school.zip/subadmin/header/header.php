<?php 


?>
<center>
                <h1 style="padding-top:0px;text-transform: uppercase;font-weight:normal; font-size:0px"> 
             <span Font-Weight="Bold" style=" color:white;font-family:Algerian;font-size:80px;">SMART SCHOOL</span></h1></center>
          