</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>



</br><style type="text/css">
<!--
body {
	background-color: #F2F2F2;
}
-->
</style> 
<p>&nbsp;</p>
<table width="800px" top="230px" height="284px"  align="center" bgcolor="#333" style=" border: 9px solid white;
    border-radius: 4px;
    box-sizing: border-box;">
<tr>
	      <td width="" align="center" valign="top">
          <center><h2 style="color:"><p style="color:white">Smart School</p></h2></center>
        <p style="color:white">The purpose of Smart School is to automate the existing manual system by the help of computerized
          equipment�s and full-fledged computer software, fulfilling their requirements, so that their valuable data/information
          can be stored for a longer period with easy accessing and manipulation of the same. The required software and
          hardware are easily available and easy to work with.Smart School, as described above, can lead to error free, secure, reliable and fast management system. It can assist the user to concentrate on their other activities rather to concentrate on the record keeping. Thus it will help organization in better utilization of resources. The organization can maintain computerized records without redundant entries. That means that one need not be distracted by information that is not relevant, while being able to reach the information. </p>
</td>
    </tr>
      </table>
    <h1>&nbsp;</h1>








