<?php 


?>


<div style="margin-top: 0px; background-color:#f2f2f2; padding-top:0px; padding-bottom: 0px;height:100px;"> 
                <div style="width: 400px; height:100px;float: left;200px;">
                    <a href="index.php">
     <img  src="image/educationboard.jpg" height="100px" width="100px" alt="Logo" onclick="return Img1_onclick()" style=" border-radius:100px " /></a>
                </div>
                <h1 style="padding-top:0px;text-transform: uppercase;font-weight:normal; font-size:0px"> 
                <span Font-Weight="Bold" style="font-family:Algerian;font-size:80px;">SMART SCHOOL</span>
                </h1>

