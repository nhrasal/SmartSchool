<?php


?>
<style>


</style>

<td><div id="implink">

<td><h2><b><p style="color:white">Important Link</p></b></h2></td>

<ul><li><div> <p style="color:white"><a href="http://www.moedu.gov.bd/" target="_blank"><img src="image/mins.jpg"  width="30px" height="30px" style=" border-radius: 30px"/>Mns. Education</a></p></div></li></ul>
<td><ul><li><div> <p style="color:white"><a href="http://www.educationboardresults.gov.bd/" target="_blank"><img src="image/educationboard.jpg"  width="30px" height="30px" style=" border-radius: 30px"/>Higher Education</a></p></div></li></ul> </td>
<td><ul><li><div> <p style="color:white"><a href="http://www.dpe.gov.bd/" target="_blank"><img src="image/primary.jpg"  width="30px" height="30px" style=" border-radius: 30px"/>PDE Education</a></p></div></li></ul> </td>
