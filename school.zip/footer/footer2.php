<?php

?>
<ul>
  <li class="">
    <a href="" class="">About Us</a><br />
    <div class="">
      <a href="mfc.php">Message form chairman</a><br />
      <a href="mfp.php">Message form Principal</a><br />
      <a href="govb.php">Governing Body</a><br />
   
    </div>
	</li>
	<li class="">
    <a href="" class="">Information</a><br />
    <div class="">
	   <a href="notice.php">Notice</a><br />
      <a href="facilities.php">Facilities</a><br />
	  <a href="library.php">Library</a><br />
	  </div>
	  </li>
	  <li class="">
	    <a href="" class="">Academic</a><br />
    <div class="">
      <a href="lesson.php">Lesson Plan</a><br />
	  <a href="classr.php">Class Routine</a><br />
      <a href="exams.php">Exam Schedule</a><br />
	 
	  </div>
	  </li>
	  <li class="\">
	    <a href="" class="">Admission</a>
    <div class="">
      <a href="form.php">Online Admisson </a><br />
	   <a href="scholarship.php">Scholarship</a><br />
	  <a href="admissionr.php">Admission Results</a>

	  </div>
	  </li>
	  <li class="">
	    <a href="" class="">Campus Life</a>
    <div class="">
      <a href="photos.php">Photos</a><br />
	   <a href="videos.php">Videos</a>
      
	  </div>
	  </li>
      <li class="">
	    <a href="" class="">Login</a>
    <div class="">
      <a href="tlogin.php">Teacher</a><br />
	   <a href="slogin.php">Student</a><br />
       <a href="adminlogin.php">Admin</a><br />
      
	  </div>
	  </li>
</ul>


