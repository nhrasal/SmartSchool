<?php

?>
<center>
<ul>
<li><a href="index.php"> Home</a></li>
  <li class="dropdown">
    <a href="" class="dropbtn">About Us</a>
    <div class="dropdown-content">
      <a href="mfc.php">Message form chairman</a>
      <a href="mfp.php">Message form Principal</a>
      <a href="govb.php">Governing Body</a>
	  <a href="history.php">History</a>
      <a href="achi.php">Achievements</a>
   
    </div>
	</li>
	<li class="dropdown">
    <a href="" class="dropbtn">Information</a>
    <div class="dropdown-content">
      <a href="news.php">News</a>
	   <a href="notice.php">Notice</a>
      <a href="facilities.php">Facilities</a>
	  <a href="library.php">Library</a>
      <a href="publication.php">Publication</a>
	  <a href="teacherinfo.php">Teacher Info</a>
	  </div>
	  </li>
	  <li class="dropdown">
	    <a href="" class="dropbtn">Academic</a>
    <div class="dropdown-content">
      <a href="cfc.php">Code of Conduct</a>
	   <a href="guidl.php">Guideline</a>
      <a href="lesson.php">Lesson Plan</a>
	  <a href="classr.php">Class Routine</a>
      <a href="exams.php">Exam Schedule</a>
	 
	  </div>
	  </li>
	  <li class="dropdown">
	    <a href="" class="dropbtn">Admission</a>
    <div class="dropdown-content">
      <a href="form.php">Online Admisson </a>
	   <a href="scholarship.php">Scholarship</a>
      <a href="factf.php">Fast Facts</a>
	  <a href="admissionr.php">Admission Results</a>

	  </div>
	  </li>
	  <li class="dropdown">
	    <a href="" class="dropbtn">Campus Life</a>
    <div class="dropdown-content">
      <a href="photos.php">Photos</a>
	   <a href="videos.php">Videos</a>
      
	  </div>
	  </li>
	  
	  <li><a href="notice.php"> Notice</a></li>
	  <li><a href="contact.php"> Contact</a></li>
	  <li><a href="employment.php"> Employment</a></li>
	  <li><a href="achievements.php"> Achievements</a></li>
      
	  <li class="dropdown">
	    <a href="" class="dropbtn">Login</a>
    <div class="dropdown-content">
    <a href="adminlogin.php">Admin</a>
      <a href="tlogin.php">Teacher</a>
	   <a href="slogin.php">Student</a>
      
	  </div>
	  </li>
</ul>
</cebter>