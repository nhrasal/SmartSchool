<?php 


?>
<style>
#head{
	height:100px;
	top:0px;
	position:absolute;
	width:90%;
	left:200px;
	position:absolute;
	background-color:#bd5d38;
	
}
</style>
<center><div id="head">
                <h1  style="padding-top:0px;text-transform: uppercase;font-weight:normal; font-size:0px"> 
             <span Font-Weight="Bold" style="font-family:Algerian;font-size:90px; color:white">SMART SCHOOL</span></h1></center>
          </div>